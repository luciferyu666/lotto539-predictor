
import argparse, json, os, numpy as np
from core.rl_agent import PPOAgent
from core.optimizer import evo_optimize
from core.core_pool import build_core_pool
from core.wheel_generator import gen_wheels

def main(issue:int):
    np.random.seed(42)
    scores = np.random.rand(39)
    ranking = list(np.argsort(scores)[::-1])
    rough_pool = ranking[:25]
    core_pool = build_core_pool(ranking, scores)
    wheels = gen_wheels(core_pool)
    os.makedirs('outputs', exist_ok=True)
    json.dump({'issue':issue,'core_pool':core_pool,'wheels':wheels},
              open(f'outputs/{issue}_m4_output.json','w'), ensure_ascii=False, indent=2)
    print("Core pool:", core_pool)
    print("Generated wheels:", wheels)
if __name__=='__main__':
    import sys, pathlib
    ap = argparse.ArgumentParser()
    ap.add_argument('--issue', type=int, required=True)
    args = ap.parse_args()
    main(args.issue)
