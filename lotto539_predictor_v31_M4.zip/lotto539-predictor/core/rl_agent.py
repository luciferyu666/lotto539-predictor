
"""PPO v3.1 (簡化版) — 針對今彩 539 預測使用的 Actor‑Critic 實作。
本版本重點：提供 `optimize(scores)` 快速介面，直接將 NN 分數向量轉為高→低排序索引。
如需完整 on‑policy 訓練，請擴充 `select_action` / `update` 兩個方法。"""
import numpy as np

class PPOAgent:
    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or {}
        self.epsilon_max = self.cfg.get('epsilon_max', 0.4)

    # ---- 簡化介面：直接依分數 vector 排序 ----
    def optimize(self, scores: np.ndarray | list[float]) -> list[int]:
        """scores -> list(sorted indices desc)"""
        return list(np.argsort(scores)[::-1])
