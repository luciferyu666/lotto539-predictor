
import random, itertools

def gen_wheels(core_pool: list[int], total=10) -> list[list[int]]:
    """Generate hybrid wheels: 6 High‑priority + 4 Low‑priority groups."""
    core_pool = sorted(core_pool)
    high = core_pool[:len(core_pool)//2]
    low = core_pool[len(core_pool)//2:]
    wheels = []
    # High groups
    for _ in range(6):
        wheels.append(random.sample(high, 5))
    # Low groups (mix high/low)
    for _ in range(4):
        wheels.append(random.sample(high, 3) + random.sample(low, 2))
    # Guard‑Plus: ensure Jaccard distance ≥ 0.6
    final = []
    for w in wheels:
        if all(len(set(w)&set(v))/5 <= 0.4 for v in final):
            final.append(sorted(w))
        if len(final) == total:
            break
    return final
