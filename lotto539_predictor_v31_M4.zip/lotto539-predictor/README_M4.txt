Includes Adaptive‑σ Elastic-K and Hybrid Wheel 2.6 modules.
