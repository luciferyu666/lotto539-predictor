
def test_imports():
    import core.data_update
    import core.feature_engineering
    import core.neural_net
    import core.rl_agent
    import core.optimizer
    import core.core_pool
    import core.wheel_generator
