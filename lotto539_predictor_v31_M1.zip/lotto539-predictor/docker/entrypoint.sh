#!/bin/bash
python3 scripts/run_v31_pipeline.py --issue ${ISSUE:-114129}
