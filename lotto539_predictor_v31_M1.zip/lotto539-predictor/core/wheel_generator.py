
"""Hybrid Wheel 2.6 placeholder"""
def gen_wheels(core):
    return [core]
