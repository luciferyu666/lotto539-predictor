
"""Adaptive-σ Elastic-K placeholder"""
def build_core_pool(pool, feats):
    return pool[:16]
