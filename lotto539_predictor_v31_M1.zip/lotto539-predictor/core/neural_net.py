
"""BiGRU + Attention scorer (placeholder)"""
import torch, torch.nn as nn, math
class BiGRUScorer(nn.Module):
    def __init__(self, feat_dim: int = 6):
        super().__init__()
        self.bigru = nn.GRU(input_size=feat_dim, hidden_size=64,
                            num_layers=1, bidirectional=True, batch_first=True)
        self.att_q = nn.Linear(128, 128, bias=False)
        self.att_k = nn.Linear(128, 128, bias=False)
        self.att_v = nn.Linear(128, 128, bias=False)
        self.out = nn.Sequential(nn.Linear(128, 32), nn.ReLU(), nn.Linear(32, 1))

    def forward(self, x):
        h, _ = self.bigru(x)
        q,k,v = self.att_q(h), self.att_k(h), self.att_v(h)
        att = torch.matmul(q, k.transpose(-2,-1)) / math.sqrt(k.size(-1))
        w = torch.softmax(att, dim=-1)
        ctx = torch.matmul(w, v).mean(1)
        return torch.sigmoid(self.out(ctx)).squeeze(-1)
