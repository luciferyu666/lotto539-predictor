
"""Feature engineering for lotto539 predictor v3.1"""
import pandas as pd
import numpy as np
def build_features(df: pd.DataFrame) -> pd.DataFrame:
    # very simplified placeholder
    df_feat = df.copy()
    df_feat['sum'] = df[['n1','n2','n3','n4','n5']].sum(axis=1)
    return df_feat
