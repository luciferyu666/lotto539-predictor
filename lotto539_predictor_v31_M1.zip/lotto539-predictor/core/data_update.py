
"""Data update utilities for lotto539 predictor v3.1"""

import pandas as pd
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parents[2] / 'data' / 'lotto539.csv'

def update_dataset(new_issue: int, numbers):
    """Append new draw to CSV if not exists."""
    df = pd.read_csv(DATA_PATH)
    if new_issue in df['issue'].values:
        return False
    row = {'issue': new_issue, **{f"n{i+1}": n for i, n in enumerate(numbers)}}
    df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    df.to_csv(DATA_PATH, index=False)
    return True
