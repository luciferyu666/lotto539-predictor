
"""Evolutionary optimizers (GA / DE / PSO) — v3.1 簡化版。
回傳長度 17 的排序索引清單，符合 Elastic‑K 上限規格。"""
import random, numpy as np

def _fitness(idx_list, scores):
    return float(np.sum(scores[list(idx_list)]))

def ga_optimize(scores, k=17, pop=180, gens=40, mutate=0.1):
    n = len(scores)
    population = [random.sample(range(n), k) for _ in range(pop)]
    for _ in range(gens):
        population.sort(key=lambda ind: -_fitness(ind, scores))
        survivors = population[:pop//2]
        children = []
        while len(children) < pop//2:
            p1, p2 = random.sample(survivors, 2)
            cut = random.randint(1, k-1)
            child = list(dict.fromkeys(p1[:cut] + p2[cut:]))
            while len(child) < k:
                r = random.randrange(n)
                if r not in child:
                    child.append(r)
            # mutation
            if random.random() < mutate:
                child[random.randint(0, k-1)] = random.randrange(n)
            children.append(child[:k])
        population = survivors + children
    best = max(population, key=lambda ind: _fitness(ind, scores))
    return sorted(best)[:k]

def evo_optimize(scores, method='GA'):
    if method.upper() == 'GA':
        return ga_optimize(scores)
    # fallback GA
    return ga_optimize(scores)
