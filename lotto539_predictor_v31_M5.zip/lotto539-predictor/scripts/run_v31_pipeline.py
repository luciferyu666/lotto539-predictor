
import argparse, json, os, numpy as np
from core.rl_agent import PPOAgent
from core.optimizer import evo_optimize
from core.core_pool import build_core_pool
from core.wheel_generator import gen_wheels
from scripts.backtest_mc import monte_carlo_eval
from core.kpi_monitor import kpi_pass

def main(issue:int):
    np.random.seed(42)
    scores = np.random.rand(39)
    ranking = list(np.argsort(scores)[::-1])
    core_pool = build_core_pool(ranking, scores)
    wheels = gen_wheels(core_pool)
    # KPI evaluation
    kpi = monte_carlo_eval(core_pool, wheels)
    status = 'PASS' if kpi_pass(kpi) else 'FAIL'
    print('KPI:', kpi, 'Status:', status)
    os.makedirs('outputs', exist_ok=True)
    json.dump({'issue':issue,'core_pool':core_pool,'wheels':wheels,'kpi':kpi,'status':status},
              open(f'outputs/{issue}_m5_output.json','w'), ensure_ascii=False, indent=2)

if __name__=='__main__':
    import sys
    ap = argparse.ArgumentParser()
    ap.add_argument('--issue', type=int, required=True)
    args = ap.parse_args()
    main(args.issue)
