Adds Re‑Balancer and Meta‑PSO 2.1 optimisation layer.
