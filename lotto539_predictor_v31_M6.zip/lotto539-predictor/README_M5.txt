Adds Monte-Carlo 500k KPI evaluation & Early-Stop monitor.
