
import numpy as np

def elastic_k(sigma_h: float, warm_ratio: float, short_hot_cnt: int) -> int:
    """Dynamic K size based on σₕ and熱度比率."""
    if sigma_h >= 0.18:
        return 17
    if 0.05 <= sigma_h < 0.18:
        return 16 if warm_ratio >= 0.25 else 15
    if 0.02 <= sigma_h < 0.05:
        return 14
    return 15 if short_hot_cnt >= 3 else 13

def build_core_pool(sorted_idx: list[int], scores: np.ndarray) -> list[int]:
    """Apply elastic_k rule and guard‑plus to decide final core pool."""
    sigma_h = float(np.std(scores))
    warm_ratio = float(np.mean(scores > np.percentile(scores, 88)))
    short_hot_cnt = int(np.sum(scores > np.percentile(scores, 95)))
    k = elastic_k(sigma_h, warm_ratio, short_hot_cnt)
    core_pool = sorted_idx[:k]
    # Guard‑Plus：若冷號過多，替換最低分號
    if np.sum(scores[core_pool] < np.percentile(scores, 40)) > 2:
        replace_candidates = np.argsort(scores)[::-1][k:k+5]
        for rep in replace_candidates:
            cold_idx = [i for i in core_pool if scores[i] < np.percentile(scores, 40)]
            if not cold_idx: break
            core_pool[core_pool.index(cold_idx[0])] = int(rep)
    return sorted(core_pool)
