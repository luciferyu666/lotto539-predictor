
"""Post‑GA Re‑Balancer + Meta‑PSO 2.1
Re‑balance wheel combinations if KPI 未達標或 σₕ 過高。
"""
import numpy as np, random
from core.optimizer import pso_optimize, ga_optimize

def re_balance(wheels, scores, max_iter=100):
    """簡化：若任一輪盤包含過多低分號→用高分號替換。"""
    high_idx = list(np.argsort(scores)[-12:])  # top 12
    new_wheels=[]
    for w in wheels:
        w=list(w)
        low=[n for n in w if n not in high_idx]
        for i in range(len(low)):
            if random.random() < .5:
                candidate=random.choice(high_idx)
                if candidate not in w:
                    w[w.index(low[i])] = candidate
        new_wheels.append(sorted(w))
    return new_wheels

# -------- Meta‑PSO 2.1 -----------
def meta_pso(wheels, scores, iters=60):
    """利用 PSO 在 wheel space 進行細部優化。
    每輪將一個 wheel 視為粒子位置 (5 維)，以分數和為 fitness。"""
    num=39
    dim=5
    swarm=[np.array(w) for w in wheels]
    vel=[np.zeros(dim) for _ in swarm]
    pbest=swarm.copy()
    def fit(w): return scores[list(w)].sum()
    pbest_score=[fit(p) for p in pbest]
    gbest=pbest[np.argmax(pbest_score)].copy()
    w_in, c1, c2 = 0.6, 1.2, 1.2
    for _ in range(iters):
        for i in range(len(swarm)):
            r1,r2=np.random.rand(dim),np.random.rand(dim)
            vel[i]=w_in*vel[i]+c1*r1*(pbest[i]-swarm[i])+c2*r2*(gbest-swarm[i])
            swarm[i]=swarm[i]+vel[i]
            swarm[i]=np.clip(np.round(swarm[i]),0,num-1)
            # uniqueness
            uniq=list(dict.fromkeys(swarm[i].astype(int)))
            while len(uniq)<dim:
                r=random.randrange(num)
                if r not in uniq: uniq.append(r)
            swarm[i]=np.array(sorted(uniq))[:dim]
            sc=fit(swarm[i])
            if sc>pbest_score[i]:
                pbest[i]=swarm[i].copy()
                pbest_score[i]=sc
                if sc>fit(gbest):
                    gbest=swarm[i].copy()
    # Replace worst wheel with gbest
    worst_idx=np.argmin([fit(w) for w in wheels])
    wheels[worst_idx]=sorted(gbest.astype(int))
    return wheels
