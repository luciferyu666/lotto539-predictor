
import argparse, pandas as pd
from core.data_update import LotteryDataManager
from core.feature_engineering import build_features
from core.neural_net import BiGRUScorer
import torch, numpy as np

def main(issue:int):
    dm=LotteryDataManager()
    df=dm.load()
    feats=build_features(df)
    model=BiGRUScorer(feats.shape[1])
    x=torch.tensor(feats.values,dtype=torch.float32).unsqueeze(0)
    scores=model(x).detach().numpy()[0]
    print("Mock scores calc", scores[:5])

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--issue',type=int,required=True)
    args=ap.parse_args()
    main(args.issue)
