
def gen_wheels(core):
    high=core[:10]
    low=core[-10:]
    return [high, low]
