
def evo_optimize(pool):
    return pool
