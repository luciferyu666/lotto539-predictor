
import pandas as pd, numpy as np

def rolling_hot(df:pd.DataFrame, window:int)->pd.DataFrame:
    nums=df[['n1','n2','n3','n4','n5']]
    hot=nums.apply(lambda col: col.rolling(window).apply(lambda x: (x==col.iloc[-1]).sum()), raw=False)
    return hot.add_prefix(f'hot{window}_')

def build_features(df: pd.DataFrame)->pd.DataFrame:
    feats = df.copy()
    feats['sum'] = df[['n1','n2','n3','n4','n5']].sum(axis=1)
    for w in (200,700,1500):
        feats = pd.concat([feats, rolling_hot(df,w)], axis=1)
    return feats.fillna(0)
