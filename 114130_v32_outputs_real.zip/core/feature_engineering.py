
import pandas as pd
def tri_layer_features(df):
    # assume df has columns n1..n5
    nums = df[['n1','n2','n3','n4','n5']]
    hot_short = nums.rolling(200).mean()
    hot_medium = nums.rolling(700).mean()
    hot_long = nums.rolling(1500).mean()
    feats = pd.concat([hot_short.add_prefix('s_'),
                       hot_medium.add_prefix('m_'),
                       hot_long.add_prefix('l_')], axis=1).fillna(0)
    return feats
