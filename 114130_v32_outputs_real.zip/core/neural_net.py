
import torch, torch.nn as nn, math
class BiGRUScorer(nn.Module):
    def __init__(self, feat_dim):
        super().__init__()
        self.gru = nn.GRU(feat_dim, 64, 2, batch_first=True, bidirectional=True)
        self.q = nn.Linear(128,128,bias=False)
        self.k = nn.Linear(128,128,bias=False)
        self.v = nn.Linear(128,128,bias=False)
        self.head = nn.Linear(128,1)
    def forward(self,x):
        h,_ = self.gru(x)
        q,k,v = self.q(h), self.k(h), self.v(h)
        att = (q@k.transpose(-2,-1))/math.sqrt(k.size(-1))
        w = att.softmax(-1)
        ctx = (w@v).mean(1)
        return torch.sigmoid(self.head(ctx)).squeeze(-1)
