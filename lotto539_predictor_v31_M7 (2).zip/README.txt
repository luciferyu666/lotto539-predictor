Lotto539 predictor v3.1 M7 package. Run ./run_all.sh to verify.
