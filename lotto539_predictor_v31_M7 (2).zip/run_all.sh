#!/usr/bin/env bash
python - <<'PY'
import subprocess, sys, os, venv, json, pathlib, textwrap
print("Creating venv...")
venv_dir='venv_test'
venv.create(venv_dir, with_pip=True)
pip=os.path.join(venv_dir,'bin','pip')
python_bin=os.path.join(venv_dir,'bin','python')
subprocess.check_call([pip,'install','numpy','pyyaml'])
subprocess.check_call([python_bin,'scripts/run_pipeline.py','--issue','114129'])
print("DONE")
PY
