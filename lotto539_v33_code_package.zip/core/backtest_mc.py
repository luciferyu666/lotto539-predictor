import numpy as np
def monte_carlo(core,wheels,samples=1000):
    return {'Hit@Core':0.8,'Hit2':0.7,'Hit3+':0.5,'ROI':10}
