def pso_optimize(seed,scores,iters=10): return seed
