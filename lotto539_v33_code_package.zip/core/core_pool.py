def build_core_pool(ranking,warm): return ranking[:16]
