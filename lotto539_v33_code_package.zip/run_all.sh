#!/usr/bin/env bash
pip install -r requirements.txt
python scripts/run_v33_pipeline.py
