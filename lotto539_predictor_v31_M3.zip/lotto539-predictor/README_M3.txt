Lotto539 predictor v3.1 — M3 package (PPO v3.1 & Evolutionary Optimizer).
