
import argparse, json, os, numpy as np
from core.rl_agent import PPOAgent
from core.optimizer import evo_optimize

def main(issue: int):
    # 假設已有 39 個球號分數，這裡以隨機數示範
    np.random.seed(42)
    scores = np.random.rand(39)

    agent = PPOAgent({'epsilon_max': 0.4})
    ranking = agent.optimize(scores)

    core_pool = evo_optimize(np.array(scores), method='GA')

    print(f"Issue {issue} core pool (17 nums):", core_pool)

    os.makedirs('outputs', exist_ok=True)
    with open(f'outputs/{issue}_core_pool.json', 'w', encoding='utf-8') as f:
        json.dump({'issue': issue, 'core_pool': core_pool}, f, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--issue', type=int, required=True)
    args = ap.parse_args()
    main(args.issue)
